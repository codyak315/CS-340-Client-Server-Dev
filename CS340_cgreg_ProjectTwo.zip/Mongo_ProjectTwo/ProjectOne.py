from pymongo import MongoClient
from bson.objectid import ObjectId
from bson.json_util import dumps

class AnimalShelter(object):
    
    def __init__(self, username, password):
        #Initializing the MongoClient. This helps to access the MongoDB databases and collections.
        #username = "aacuser"
        #password = "MniCia21"
        self.client = MongoClient('mongodb://%s:%s@localhost:56031/AAC' % (username, password))
        self.database = self.client['AAC']
        
    #CRUD Create method that inserts a document into a specified MongoDB database and collection
    def create(self, data):
        out = False
        
        if data is not None:
            self.database.animals.insert(data) #data should be dictionary
            out = True
        else:
            raise Exception("Nothing to save, because data parameter is empty")
            
        return out
            
    #CRUD Read method that queries for document(s) from a specified MongoDB database and specified collection
    def read(self, data):
        if data is not None:
            result = self.database.animals.find(data, {"_id": False})
            
            #dumps(result) to return values (tester for valid output)
            
            return result #returns cursor
        else:
            raise Exception("Nothing to read, because data parameter is not valid")
            
    
    #CRUD Update method that queries for and changes document(s) from a specified MongoDB database and collection
    def update(self, query, data):
        if data is not None:
            result = self.database.animals.update(query, data)
            
            #Tester for valid output
            #output = self.database.animals.find(data)
            
            return dumps(result)
        else:
            raise Exception("Nothing to update, because data parameter is not valid")
            
    
    #CRUD Delete method that queries for and removes document(s) from a specified MongoDB database and specified collection
    def delete(self, data):
        if data is not None:
            result = self.database.animals.remove(data)
            return dumps(result)
        else:
            raise Exception("Nothing to delete, because data parameter is not valid")
            
            
            
    def waterFilter(self, data):
        if data is not None:
            result = self.database.animals.find({"animal_type":"Dog","breed":{"$in":["Labrador Retriever Mix","Chesapeake Bay Retriever","Newfoundland"]}, "sex_upon_outcome":"Intact Female","age_upon_outcome_in_weeks":{"$gte":26},"age_upon_outcome_in_weeks":{"$lte":156}}, {"_id":False})
            return result
        else:
            raise Exception("Nothing to read, because data parameter is not valid")
            
            
            
    def mountainFilter(self, data):
        if data is not None:
            result = self.database.animals.find({"animal_type":"Dog","breed":{"$in":["German Shepherd", "Alaskan Malamute","Old English Sheepdog", "Siberian Husky", "Rottweiler"]}, "sex_upon_outcome":"Intact Male","age_upon_outcome_in_weeks":{"$gte":26},"age_upon_outcome_in_weeks":{"$lte":156}}, {"_id": False})
            return result
        else:
            raise Exception("Nothing to read, because data parameter is not valid")
            
            
            
    def disasterFilter(self, data):
        if data is not None:
            result = self.database.animals.find({"animal_type":"Dog","breed":{"$in":["Doberman Pinscher","German Shepherd","Golden Retriever","Bloodhound", "Rottweiler"]}, "sex_upon_outcome":"Intact Male","age_upon_outcome_in_weeks":{"$gte":20},"age_upon_outcome_in_weeks":{"$lte":300}}, {"_id":False})
            return result
        else:
            raise Exception("Nothing to read, because data parameter is not valid")
            
            
            
            
            